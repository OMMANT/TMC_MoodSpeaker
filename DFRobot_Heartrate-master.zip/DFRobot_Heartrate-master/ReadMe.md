# DFRobot_Heartrate

```
***************************************************************
* Arduino Heartrate Library - Version 1.1
* by linfeng<490289303@qq.com>
*
* This Library is licensed under a GPLv3 License
***************************************************************
```
For an ultra-detailed explanation of why the code is the way it is, please visit:   
[Chinese Wiki](http://wiki.dfrobot.com.cn/index.php?title=(SKU:SEN0203)%E5%BF%83%E7%8E%87%E4%BC%A0%E6%84%9F%E5%99%A8heart_rate_sensor)  
[English Wiki](https://www.dfrobot.com/wiki/index.php?title=Heart_Rate_Sensor_SKU:_SEN0203)
